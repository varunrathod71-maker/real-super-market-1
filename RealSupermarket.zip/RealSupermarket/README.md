# Real Supermarket (native Android, Kotlin + Jetpack Compose + Room)

## Build the APK without a PC (GitHub Actions)
1. Push this folder to a GitHub repository (branch `main`).
2. Open the repo > **Actions** > "Build APK" (it runs automatically on every push).
3. When it turns green, open the run > **Artifacts** > download `RealSupermarket-debug-apk`.
4. Unzip it, install `app-debug.apk` on your phone (allow "install unknown apps").

## Logins
- Admin: phone field `admin`, password `admin123` (change it in Admin > Settings).
- Customers: tap "Sign up" on the login screen.

## Structure
- `data/` Room database, DAOs, repository (all authorization is enforced in ShopRepository)
- `auth/` session + password hashing
- `logic/` money, validation, grocery-list parsing, bullets
- `ui/` theme, reusable components, screens, navigation, ViewModel

## Known limits
- Data is stored on the phone (Room/SQLite). Swap the DAO calls in ShopRepository for API calls to use a hosted backend.
- UPI payments are NOT verified by the app; the admin marks them received.
- Admin security is app-level (local database), not a real server.
