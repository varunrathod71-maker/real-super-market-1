package com.realsupermarket.app.data

import androidx.room.withTransaction
import com.realsupermarket.app.auth.AuthManager
import com.realsupermarket.app.auth.PasswordHasher
import com.realsupermarket.app.logic.Validate
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map

data class ShopSettings(
    val shopName: String = "Real Supermarket",
    val phone: String = "",
    val address: String = "",
    val upiId: String = ""
)

/** One grocery line as submitted by the customer. price == null means "I don't know the price". */
data class OrderLine(val name: String, val qtyLabel: String, val qtyUnknown: Boolean, val price: Double?, val productId: Long?)

data class PlaceOrderRequest(
    val lines: List<OrderLine>,
    val fulfillment: String,
    val name: String,
    val phone: String,
    val address: String,
    val payment: String
)

sealed interface OrderLookup {
    data object Missing : OrderLookup
    data class Found(val order: OrderWithItems) : OrderLookup
}

/**
 * The single gateway to data. Authorization is enforced HERE (not just hidden in the UI):
 *  - customers only ever receive their own orders,
 *  - every admin read/write re-checks the signed-in user's role in the database.
 * To move to a hosted backend later, replace the DAO calls in this class with API calls.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class ShopRepository(private val db: ShopDatabase, private val auth: AuthManager) {
    private val dao = db.dao()

    // ---------- session / public data
    val currentUser: Flow<UserEntity?> =
        auth.userId.flatMapLatest { id -> if (id == null) flowOf(null) else dao.userFlow(id) }
    val activeProducts: Flow<List<ProductEntity>> = dao.activeProducts()
    val settings: Flow<ShopSettings> = dao.settings().map { rows ->
        val m = rows.associate { it.k to it.v }
        ShopSettings(m["shop_name"] ?: "Real Supermarket", m["shop_phone"] ?: "", m["shop_address"] ?: "", m["upi_id"] ?: "")
    }
    val myOrders: Flow<List<OrderWithItems>> =
        auth.userId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.ordersForUser(id) }

    // ---------- admin-only flows (empty for anyone who is not an admin)
    private fun <T> adminFlow(empty: T, source: () -> Flow<T>): Flow<T> =
        auth.userId.flatMapLatest { id ->
            flow {
                val ok = id != null && dao.userById(id)?.role == Role.ADMIN
                if (ok) emitAll(source()) else emit(empty)
            }
        }

    val allOrders: Flow<List<OrderWithItems>> = adminFlow(emptyList()) { dao.allOrders() }
    val allProducts: Flow<List<ProductEntity>> = adminFlow(emptyList()) { dao.allProducts() }
    val customers: Flow<List<UserEntity>> = adminFlow(emptyList()) { dao.customers() }

    /** One order; visible only to its owner or an admin. */
    fun order(id: Long): Flow<OrderLookup> = auth.userId.flatMapLatest { uid ->
        flow {
            val me = uid?.let { dao.userById(it) }
            val o = dao.orderOnce(id)
            val allowed = me != null && o != null && (me.role == Role.ADMIN || o.userId == me.id)
            if (allowed) {
                emitAll(dao.orderWithItems(id).map { if (it == null) OrderLookup.Missing else OrderLookup.Found(it) })
            } else {
                emit(OrderLookup.Missing)
            }
        }
    }

    private suspend fun requireAdmin() {
        val id = auth.userId.value ?: throw SecurityException("Please sign in first.")
        if (dao.userById(id)?.role != Role.ADMIN) throw SecurityException("Admin access required.")
    }

    // ---------- accounts
    suspend fun seedIfNeeded() {
        if (dao.userCount() > 0) return
        val salt = PasswordHasher.newSalt()
        dao.insertUser(
            UserEntity(
                name = "Shop Admin", phone = "admin",
                passHash = PasswordHasher.hash("admin123", salt), salt = salt,
                role = Role.ADMIN, createdAt = System.currentTimeMillis()
            )
        )
        listOf(
            ProductEntity(name = "Rice", description = "Everyday rice, sold loose", category = "Grains", price = 120.0, stock = 200.0, unit = "kg", emoji = "🍚", active = true, loose = true),
            ProductEntity(name = "Toor Dal", description = "Split pigeon peas, sold loose", category = "Pulses", price = 160.0, stock = 100.0, unit = "kg", emoji = "🥜", active = true, loose = true),
            ProductEntity(name = "Sugar", description = "Refined sugar", category = "Grocery", price = 45.0, stock = 150.0, unit = "kg", emoji = "🍬", active = true, loose = true),
            ProductEntity(name = "Sunflower Oil", description = "Refined sunflower oil", category = "Oil", price = 150.0, stock = 80.0, unit = "litre", emoji = "🌻", active = true, loose = false),
            ProductEntity(name = "Milk", description = "Fresh milk packet", category = "Dairy", price = 60.0, stock = 60.0, unit = "packet", emoji = "🥛", active = true, loose = false),
            ProductEntity(name = "Tomato", description = "Fresh tomatoes", category = "Vegetables", price = 30.0, stock = 50.0, unit = "kg", emoji = "🍅", active = true, loose = true),
            ProductEntity(name = "Parle-G", description = "Glucose biscuits", category = "Snacks", price = 10.0, stock = 300.0, unit = "packet", emoji = "🍪", active = true, loose = false)
        ).forEach { dao.upsertProduct(it) }
        dao.putSetting(SettingEntity("shop_name", "Real Supermarket"))
        dao.putSetting(SettingEntity("shop_phone", ""))
        dao.putSetting(SettingEntity("shop_address", ""))
        dao.putSetting(SettingEntity("upi_id", ""))
    }

    suspend fun currentUserOnce(): UserEntity? = auth.userId.value?.let { dao.userById(it) }

    suspend fun register(name: String, phone: String, password: String): UserEntity {
        Validate.name(name)?.let { throw IllegalArgumentException(it) }
        Validate.phone(phone)?.let { throw IllegalArgumentException(it) }
        Validate.password(password)?.let { throw IllegalArgumentException(it) }
        if (dao.userByPhone(phone.trim()) != null) {
            throw IllegalArgumentException("This mobile number is already registered. Please log in.")
        }
        val salt = PasswordHasher.newSalt()
        val id = dao.insertUser(
            UserEntity(
                name = name.trim(), phone = phone.trim(),
                passHash = PasswordHasher.hash(password, salt), salt = salt,
                role = Role.CUSTOMER, createdAt = System.currentTimeMillis()
            )
        )
        auth.signIn(id)
        return dao.userById(id)!!
    }

    suspend fun login(phone: String, password: String): UserEntity {
        val u = dao.userByPhone(phone.trim()) ?: throw IllegalArgumentException("No account found for this mobile number.")
        if (PasswordHasher.hash(password, u.salt) != u.passHash) throw IllegalArgumentException("Wrong password. Please try again.")
        auth.signIn(u.id)
        return u
    }

    fun logout() = auth.signOut()

    // ---------- customer: place order
    /** Totals are recomputed here from the submitted lines; the UI is never trusted. Delivery is always FREE. */
    suspend fun placeOrder(req: PlaceOrderRequest): Long {
        val uid = auth.userId.value ?: throw SecurityException("Please sign in to place an order.")
        dao.userById(uid) ?: throw SecurityException("Please sign in to place an order.")
        if (req.lines.isEmpty()) throw IllegalArgumentException("Your order is empty. Please add at least one item.")
        Validate.name(req.name)?.let { throw IllegalArgumentException(it) }
        Validate.phone(req.phone)?.let { throw IllegalArgumentException(it) }
        if (req.fulfillment == Fulfillment.DELIVERY) Validate.address(req.address)?.let { throw IllegalArgumentException(it) }
        req.lines.forEach { l ->
            if (l.name.isBlank()) throw IllegalArgumentException("An item has no name.")
            if (!l.qtyUnknown && l.qtyLabel.isBlank()) throw IllegalArgumentException("\"${l.name}\" needs a quantity.")
            if (l.price != null && (l.price <= 0.0 || l.price > 100000.0)) throw IllegalArgumentException("\"${l.name}\" has an invalid price.")
        }
        val known = Math.round(req.lines.mapNotNull { it.price }.sum() * 100) / 100.0
        val unknown = req.lines.count { it.price == null }
        return db.withTransaction {
            val id = dao.insertOrder(
                OrderEntity(
                    orderNo = "", userId = uid, customerName = req.name.trim(), phone = req.phone.trim(),
                    fulfillment = req.fulfillment,
                    address = if (req.fulfillment == Fulfillment.DELIVERY) req.address.trim() else "",
                    payment = req.payment, paymentConfirmed = false,
                    status = OrderStatus.PLACED.name, subtotal = known, unknownCount = unknown,
                    createdAt = System.currentTimeMillis()
                )
            )
            dao.setOrderNo(id, "RS${1000 + id}")
            dao.insertItems(req.lines.map {
                OrderItemEntity(orderId = id, name = it.name.trim(), qtyLabel = it.qtyLabel, qtyUnknown = it.qtyUnknown, price = it.price, productId = it.productId)
            })
            req.lines.forEach { l -> l.productId?.let { dao.reduceStock(it, 1.0) } }
            id
        }
    }

    // ---------- admin operations (each re-checks the admin role)
    suspend fun updateStatus(orderId: Long, status: OrderStatus) { requireAdmin(); dao.setStatus(orderId, status.name) }
    suspend fun setPaymentConfirmed(orderId: Long, confirmed: Boolean) { requireAdmin(); dao.setPaymentConfirmed(orderId, confirmed) }
    suspend fun saveProduct(p: ProductEntity) { requireAdmin(); dao.upsertProduct(p) }
    suspend fun deleteProduct(id: Long) { requireAdmin(); dao.deleteProduct(id) }

    suspend fun saveSettings(s: ShopSettings) {
        requireAdmin()
        dao.putSetting(SettingEntity("shop_name", s.shopName.trim()))
        dao.putSetting(SettingEntity("shop_phone", s.phone.trim()))
        dao.putSetting(SettingEntity("shop_address", s.address.trim()))
        dao.putSetting(SettingEntity("upi_id", s.upiId.trim()))
    }

    suspend fun changePassword(oldPassword: String, newPassword: String) {
        requireAdmin()
        Validate.password(newPassword)?.let { throw IllegalArgumentException(it) }
        val u = dao.userById(auth.userId.value!!)!!
        if (PasswordHasher.hash(oldPassword, u.salt) != u.passHash) throw IllegalArgumentException("Current password is wrong.")
        val salt = PasswordHasher.newSalt()
        dao.setPassword(u.id, PasswordHasher.hash(newPassword, salt), salt)
    }
}
