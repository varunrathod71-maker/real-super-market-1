package com.realsupermarket.app.auth

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.security.MessageDigest
import java.security.SecureRandom

/** Salted SHA-256 password hashing (fine for a local DB; use a server + bcrypt/argon2 in production). */
object PasswordHasher {
    fun newSalt(): String {
        val b = ByteArray(16)
        SecureRandom().nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    fun hash(password: String, salt: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest((salt + password).toByteArray(Charsets.UTF_8))
        return d.joinToString("") { "%02x".format(it) }
    }
}

/** Remembers which user id is signed in (survives app restarts). Role is always re-read from the database. */
class AuthManager(context: Context) {
    private val prefs = context.getSharedPreferences("session", Context.MODE_PRIVATE)
    private val _userId = MutableStateFlow(prefs.getLong("uid", -1L).takeIf { it > 0 })
    val userId: StateFlow<Long?> = _userId

    fun signIn(id: Long) {
        prefs.edit().putLong("uid", id).apply()
        _userId.value = id
    }

    fun signOut() {
        prefs.edit().remove("uid").apply()
        _userId.value = null
    }
}
