package com.realsupermarket.app.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface ShopDao {
    // ---- users
    @Query("SELECT COUNT(*) FROM users") suspend fun userCount(): Int
    @Insert suspend fun insertUser(u: UserEntity): Long
    @Query("SELECT * FROM users WHERE phone = :phone LIMIT 1") suspend fun userByPhone(phone: String): UserEntity?
    @Query("SELECT * FROM users WHERE id = :id") suspend fun userById(id: Long): UserEntity?
    @Query("SELECT * FROM users WHERE id = :id") fun userFlow(id: Long): Flow<UserEntity?>
    @Query("SELECT * FROM users WHERE role = 'CUSTOMER' ORDER BY createdAt DESC") fun customers(): Flow<List<UserEntity>>
    @Query("UPDATE users SET passHash = :h, salt = :s WHERE id = :id") suspend fun setPassword(id: Long, h: String, s: String)

    // ---- products
    @Query("SELECT * FROM products WHERE active = 1 ORDER BY name") fun activeProducts(): Flow<List<ProductEntity>>
    @Query("SELECT * FROM products ORDER BY name") fun allProducts(): Flow<List<ProductEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertProduct(p: ProductEntity): Long
    @Query("DELETE FROM products WHERE id = :id") suspend fun deleteProduct(id: Long)
    @Query("UPDATE products SET stock = MAX(stock - :q, 0) WHERE id = :id") suspend fun reduceStock(id: Long, q: Double)

    // ---- orders
    @Insert suspend fun insertOrder(o: OrderEntity): Long
    @Insert suspend fun insertItems(items: List<OrderItemEntity>)
    @Query("UPDATE orders SET orderNo = :no WHERE id = :id") suspend fun setOrderNo(id: Long, no: String)
    @Transaction @Query("SELECT * FROM orders WHERE userId = :uid ORDER BY createdAt DESC") fun ordersForUser(uid: Long): Flow<List<OrderWithItems>>
    @Transaction @Query("SELECT * FROM orders ORDER BY createdAt DESC") fun allOrders(): Flow<List<OrderWithItems>>
    @Transaction @Query("SELECT * FROM orders WHERE id = :id") fun orderWithItems(id: Long): Flow<OrderWithItems?>
    @Query("SELECT * FROM orders WHERE id = :id") suspend fun orderOnce(id: Long): OrderEntity?
    @Query("UPDATE orders SET status = :s WHERE id = :id") suspend fun setStatus(id: Long, s: String)
    @Query("UPDATE orders SET paymentConfirmed = :c WHERE id = :id") suspend fun setPaymentConfirmed(id: Long, c: Boolean)

    // ---- settings
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putSetting(s: SettingEntity)
    @Query("SELECT * FROM settings") fun settings(): Flow<List<SettingEntity>>
}

@Database(
    entities = [UserEntity::class, ProductEntity::class, OrderEntity::class, OrderItemEntity::class, SettingEntity::class],
    version = 1,
    exportSchema = false
)
abstract class ShopDatabase : RoomDatabase() {
    abstract fun dao(): ShopDao
}
