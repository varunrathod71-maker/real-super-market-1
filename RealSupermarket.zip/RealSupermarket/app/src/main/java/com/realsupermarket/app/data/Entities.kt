package com.realsupermarket.app.data

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

object Role { const val ADMIN = "ADMIN"; const val CUSTOMER = "CUSTOMER" }
object Fulfillment { const val DELIVERY = "DELIVERY"; const val PICKUP = "PICKUP" }
object Payment { const val CASH = "CASH"; const val UPI = "UPI" }

enum class OrderStatus(val label: String) {
    PLACED("Order placed"),
    CONFIRMING("Confirming"),
    PREPARING("Preparing"),
    READY("Ready"),
    OUT_FOR_DELIVERY("Out for delivery"),
    DELIVERED("Delivered"),
    CANCELLED("Cancelled");

    companion object {
        fun from(name: String): OrderStatus = entries.firstOrNull { it.name == name } ?: PLACED
    }
}

@Entity(tableName = "users", indices = [Index(value = ["phone"], unique = true)])
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val passHash: String,
    val salt: String,
    val role: String,
    val createdAt: Long
)

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val description: String,
    val category: String,
    val price: Double,
    val stock: Double,
    val unit: String,
    val emoji: String,
    val active: Boolean,
    val loose: Boolean
)

/** One customer order. Prices are stored exactly as typed by the customer; unknown prices are NOT converted to 0. */
@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderNo: String,
    val userId: Long,
    val customerName: String,
    val phone: String,
    val fulfillment: String,
    val address: String,
    val payment: String,
    val paymentConfirmed: Boolean,
    val status: String,
    val subtotal: Double,      // sum of KNOWN item prices only
    val unknownCount: Int,     // number of items whose price is "to be confirmed"
    val createdAt: Long
)

@Entity(
    tableName = "order_items",
    foreignKeys = [ForeignKey(entity = OrderEntity::class, parentColumns = ["id"], childColumns = ["orderId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("orderId")]
)
data class OrderItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderId: Long,
    val name: String,
    val qtyLabel: String,
    val qtyUnknown: Boolean,
    val price: Double?,        // null = customer doesn't know the price
    val productId: Long?
)

@Entity(tableName = "settings")
data class SettingEntity(@PrimaryKey val k: String, val v: String)

data class OrderWithItems(
    @Embedded val order: OrderEntity,
    @Relation(parentColumn = "id", entityColumn = "orderId") val items: List<OrderItemEntity>
)
