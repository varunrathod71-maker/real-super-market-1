package com.realsupermarket.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.realsupermarket.app.ui.AppNav
import com.realsupermarket.app.ui.AppViewModel
import com.realsupermarket.app.ui.theme.ShopTheme

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ShopTheme { AppNav(vm) } }
    }
}
