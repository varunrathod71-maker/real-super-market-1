package com.realsupermarket.app.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.realsupermarket.app.data.Role
import com.realsupermarket.app.ui.screens.AdminMain
import com.realsupermarket.app.ui.screens.AdminOrderScreen
import com.realsupermarket.app.ui.screens.CheckoutScreen
import com.realsupermarket.app.ui.screens.CustomerMain
import com.realsupermarket.app.ui.screens.ItemDetailsScreen
import com.realsupermarket.app.ui.screens.LoginScreen
import com.realsupermarket.app.ui.screens.OrderDetailScreen
import com.realsupermarket.app.ui.screens.OrderListScreen
import com.realsupermarket.app.ui.screens.ReviewScreen
import com.realsupermarket.app.ui.screens.SplashScreen

@Composable
fun AppNav(vm: AppViewModel) {
    val nav = rememberNavController()
    val toLogin: () -> Unit = {
        vm.logout()
        nav.navigate("login") { popUpTo(nav.graph.id) { inclusive = true } }
    }
    NavHost(navController = nav, startDestination = "splash") {
        composable("splash") {
            SplashScreen(vm.startRoute) { route -> nav.navigate(route) { popUpTo("splash") { inclusive = true } } }
        }
        composable("login") {
            LoginScreen(vm) { user ->
                nav.navigate(if (user.role == Role.ADMIN) "admin" else "home") { popUpTo("login") { inclusive = true } }
            }
        }
        composable("home") {
            CustomerMain(
                vm, onStartOrder = { nav.navigate("list") },
                onOpenOrder = { nav.navigate("order/$it?placed=false") }, onLogout = toLogin
            )
        }
        composable("list") { OrderListScreen(vm, onBack = { nav.popBackStack() }, onNext = { nav.navigate("details") }) }
        composable("details") { ItemDetailsScreen(vm, onBack = { nav.popBackStack() }, onNext = { nav.navigate("review") }) }
        composable("review") {
            ReviewScreen(vm, onBack = { nav.popBackStack() }, onCheckout = { nav.navigate("checkout") },
                onStartOrder = { nav.popBackStack("home", false) })
        }
        composable("checkout") {
            CheckoutScreen(vm, onBack = { nav.popBackStack() }, onPlaced = { id ->
                nav.navigate("order/$id?placed=true") { popUpTo("home") }
            })
        }
        composable(
            "order/{id}?placed={placed}",
            arguments = listOf(
                navArgument("id") { type = NavType.LongType },
                navArgument("placed") { type = NavType.BoolType; defaultValue = false }
            )
        ) { e ->
            OrderDetailScreen(
                vm, e.arguments?.getLong("id") ?: 0L, e.arguments?.getBoolean("placed") ?: false,
                onBack = { nav.popBackStack() }
            )
        }
        composable("admin") { AdminMain(vm, onOpenOrder = { nav.navigate("admin/order/$it") }, onLogout = toLogin) }
        composable("admin/order/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
            AdminOrderScreen(vm, e.arguments?.getLong("id") ?: 0L, onBack = { nav.popBackStack() })
        }
    }
}
