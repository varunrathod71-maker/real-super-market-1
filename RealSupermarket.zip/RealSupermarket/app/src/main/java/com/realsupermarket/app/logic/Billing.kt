package com.realsupermarket.app.logic

import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import com.realsupermarket.app.data.OrderLine
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

fun fmtNum(d: Double): String = if (d % 1.0 == 0.0) d.toLong().toString() else d.toString()

object Money {
    fun fmt(v: Double): String =
        if (v % 1.0 == 0.0) "₹${v.toLong()}" else "₹" + String.format(Locale.US, "%.2f", v)

    /** Unknown prices are never shown as ₹0 — they are shown as "to be confirmed". */
    fun total(known: Double, unknown: Int): String = when {
        unknown == 0 -> fmt(known)
        known == 0.0 -> "To be confirmed"
        else -> "${fmt(known)} + $unknown item${if (unknown > 1) "s" else ""} to be confirmed"
    }
}

object DateFmt {
    fun full(ts: Long): String = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(ts))
    fun weekday(ts: Long): String = SimpleDateFormat("EEE", Locale.getDefault()).format(Date(ts))
}

object Validate {
    private val phoneRegex = Regex("^[6-9][0-9]{9}\$")

    fun name(s: String): String? = when {
        s.isBlank() -> "Please enter your full name"
        s.trim().length < 2 -> "Name is too short"
        !s.trim().all { it.isLetter() || it == ' ' || it == '.' || it == '\'' } -> "Name can only contain letters"
        else -> null
    }

    fun phone(s: String): String? = when {
        s.isBlank() -> "Please enter your mobile number"
        !phoneRegex.matches(s.trim()) -> "Enter a valid 10-digit mobile number"
        else -> null
    }

    fun address(s: String): String? = when {
        s.isBlank() -> "Please enter your delivery address"
        s.trim().length < 10 -> "Please enter the full address (house no., street, area)"
        else -> null
    }

    fun price(text: String): String? {
        val v = text.trim().toDoubleOrNull()
            ?: return "Enter a price like 150, or tick \"I don't know the price\""
        return if (v <= 0.0 || v > 100000.0) "Price must be between ₹1 and ₹1,00,000" else null
    }

    fun password(s: String): String? = if (s.length < 6) "Password must be at least 6 characters" else null
}

const val QTY_OTHER = "Other"
val QTY_OPTIONS = listOf("250 g", "500 g", "1 kg", "2 kg", "5 kg", "1 litre", "2 litre", "1 packet", "2 packets", QTY_OTHER)

/** A grocery line while the customer is still building the order. */
data class DraftItem(
    val key: String = UUID.randomUUID().toString(),
    val name: String,
    val source: String = "",           // the text line this item came from
    val qtyChoice: String = "",
    val customQty: String = "",
    val weightUnknown: Boolean = false,
    val priceText: String = "",
    val priceUnknown: Boolean = false,
    val productId: Long? = null
) {
    val qtyLabel: String
        get() = when {
            weightUnknown -> ""
            qtyChoice == QTY_OTHER -> customQty.trim()
            else -> qtyChoice
        }

    /** null means the customer does not know the price. */
    val price: Double? get() = if (priceUnknown) null else priceText.trim().toDoubleOrNull()

    fun nameError(): String? = if (name.isBlank()) "Item name can't be empty" else null

    fun qtyError(): String? = when {
        weightUnknown -> null
        qtyChoice.isEmpty() -> "Choose a quantity, or tick \"Weight not sure\""
        qtyChoice == QTY_OTHER && customQty.isBlank() -> "Type the quantity, e.g. 750 g"
        qtyChoice == QTY_OTHER && customQty.none { it.isDigit() } -> "Quantity should include a number"
        else -> null
    }

    fun priceError(): String? = if (priceUnknown) null else Validate.price(priceText)

    val isValid: Boolean get() = nameError() == null && qtyError() == null && priceError() == null

    fun toLine() = OrderLine(name.trim(), qtyLabel, weightUnknown, price, productId)
}

/** Turns typed lines like "2 kg rice" into draft items (quantity pre-filled when recognised). */
object ListParser {
    fun stripBullet(line: String): String = line.trim().trimStart('•', '-', '*', '·').trim()

    fun lines(text: String): List<String> = text.lines().map { stripBullet(it) }.filter { it.isNotEmpty() }

    private val rx = Regex(
        "^([0-9]+(?:\\.[0-9]+)?)\\s*(kgs?|gms?|grams?|g|ltr|litres?|liters?|l|ml|packets?|pkts?)\\b\\s*(?:of\\s+)?(.+)$",
        RegexOption.IGNORE_CASE
    )

    fun cap(s: String): String = s.replaceFirstChar { it.uppercase() }

    fun toItem(line: String): DraftItem {
        val m = rx.find(line) ?: return DraftItem(name = cap(line), source = line)
        val n = m.groupValues[1].toDouble()
        val num = fmtNum(n)
        val label = when (m.groupValues[2].lowercase()) {
            "kg", "kgs" -> "$num kg"
            "g", "gm", "gms", "gram", "grams" -> "$num g"
            "ml" -> "$num ml"
            "l", "ltr", "litre", "litres", "liter", "liters" -> "$num litre"
            else -> if (n == 1.0) "1 packet" else "$num packets"
        }
        val name = cap(m.groupValues[3].trim())
        return if (label in QTY_OPTIONS) DraftItem(name = name, source = line, qtyChoice = label)
        else DraftItem(name = name, source = line, qtyChoice = QTY_OTHER, customQty = label)
    }
}

/** Automatic bullet points for the grocery list text box. */
object Bullets {
    fun apply(old: TextFieldValue, new: TextFieldValue): TextFieldValue {
        var t = new.text
        var sel = new.selection.end
        val grew = t.length - old.text.length
        val newlinesAdded = t.count { it == '\n' } > old.text.count { it == '\n' }
        if (grew > 1 && newlinesAdded) { // pasted a multi-line list: bullet every line
            val rebuilt = ListParser.lines(t).joinToString("\n") { "• $it" }
            return TextFieldValue(rebuilt, TextRange(rebuilt.length))
        }
        if (old.text.isEmpty() && t.isNotBlank() && !t.startsWith("•")) {
            t = "• $t"; sel += 2
        } else if (grew == 1 && sel > 0 && t[sel - 1] == '\n') {
            t = t.substring(0, sel) + "• " + t.substring(sel); sel += 2
        }
        return new.copy(text = t, selection = TextRange(sel))
    }
}
