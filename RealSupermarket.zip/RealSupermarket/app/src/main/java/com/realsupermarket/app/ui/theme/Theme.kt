package com.realsupermarket.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val RedPrimary = Color(0xFFC62828)
val RedDark = Color(0xFF8E0000)
val RedLight = Color(0xFFFDE8E8)
val Ink = Color(0xFF222222)
val Muted = Color(0xFF6B6B6B)
val GreenOk = Color(0xFF2E7D32)
val GreenBg = Color(0xFFE3F4E4)
val Warn = Color(0xFFD84315)

@Composable
fun ShopTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = RedPrimary, onPrimary = Color.White,
            primaryContainer = RedLight, onPrimaryContainer = RedDark,
            secondary = RedPrimary, background = Color(0xFFFBF5F5), onBackground = Ink,
            surface = Color.White, onSurface = Ink,
            surfaceVariant = Color(0xFFF4ECEC), onSurfaceVariant = Muted,
            error = Color(0xFFB00020)
        ),
        shapes = Shapes(small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(24.dp)),
        content = content
    )
}
