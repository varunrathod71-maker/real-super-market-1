package com.realsupermarket.app

import android.app.Application
import androidx.room.Room
import com.realsupermarket.app.auth.AuthManager
import com.realsupermarket.app.data.ShopDatabase
import com.realsupermarket.app.data.ShopRepository

/** Application object: builds the database and repository once. */
class ShopApp : Application() {
    lateinit var repo: ShopRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val db = Room.databaseBuilder(this, ShopDatabase::class.java, "real_supermarket.db").build()
        repo = ShopRepository(db, AuthManager(this))
    }
}
